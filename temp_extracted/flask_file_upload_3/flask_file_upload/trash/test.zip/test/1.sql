SELECT * FROM users WHERE username = 'admin' OR '1'='1';
